import { Timestamp } from 'firebase/firestore';

export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  photoURL: string | null;
  stripeConnectAccountId: string | null;
  stripeCustomerId: string | null;
  expoPushToken: string | null;
  createdAt: Timestamp;
  totalEarnings: number;
  averageRating: number;
  ratingCount: number;
}
